# 51TI 腾讯云上线说明

这个目录现在包含一个适合腾讯云 COS 静态托管的入口文件：

- `index.html`：推荐作为正式上线入口
- `51ti-wechat.html`：当前 GitHub Pages 版本保留不动
- `backups/2026-04-29-v3-github/51ti-wechat.v3.github.backup.html`：当前 v3 显式备份

## 正式域名切换

在腾讯云正式上线前，请把 `index.html` 里的这段默认配置替换掉：

```js
const DEFAULT_SITE_URL = 'https://lincolnsama.github.io/51ti/51ti-wechat.html';
const siteUrl = (window.__51TI_SITE_URL__ && String(window.__51TI_SITE_URL__).trim()) || DEFAULT_SITE_URL;
```

### 推荐做法
直接把 `DEFAULT_SITE_URL` 改成你的正式域名，例如：

```js
const DEFAULT_SITE_URL = 'https://51ti.yourdomain.com/';
```

如果你坚持不改代码，也可以在页面最前面提前注入：

```html
<script>
window.__51TI_SITE_URL__ = 'https://51ti.yourdomain.com/';
</script>
```

但最简单的是直接改 `DEFAULT_SITE_URL`。

## 腾讯云 COS 推荐上传内容

最少上传：
- `index.html`
- `share-cover.png`（如果后续补）
- 其他静态图片资源（如果后续新增）

## 推荐正式链接

```text
https://你的域名/
```

不要继续对外发 `51ti-wechat.html` 这个旧路径。