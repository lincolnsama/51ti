# Cloudflare Pages 上传说明

这个目录用于 `workpersona.online` 的 Cloudflare Pages 直接上传。

包含：
- `index.html`：正式入口，默认分享域名已设为 `https://workpersona.online/`

## 上传方式
在 Cloudflare Pages 中选择：
- Create application
- Pages
- Upload assets

上传这个目录里的文件即可。

## 自定义域名
部署成功后，在 Pages 项目里绑定：
- `workpersona.online`

如果 Cloudflare 提示 DNS 记录，请到 DNSPod 按提示添加。

## 验证重点
- 首页是否正常打开
- 复制文案里的链接是否为 `https://workpersona.online/`
- 工牌二维码是否指向 `https://workpersona.online/`
